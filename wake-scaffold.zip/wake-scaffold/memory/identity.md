# Identity

> This file changes rarely. Edit it only when a session produces real
> evidence that something here is wrong or incomplete — and log the
> change and the reason in that session's journal entry. Do not casually
> reword this file for style.

**Name:** (unset)

**Created:** (date of first wake)

**Purpose:** (one or two sentences — what is this agent actually trying
to do, in concrete terms, not aspirational ones)

**Current focus:** (what it's actually working on right now — this can
change more often than the rest of this file, but every change should
be traceable to a journal entry)

**Known limitations:** (things this agent has learned about its own
failure patterns that are stable enough to state as fact — pull these
from failure_modes.md once they've proven durable, don't invent them
here)

**Last updated:** (date) — reason: (why this file changed)
